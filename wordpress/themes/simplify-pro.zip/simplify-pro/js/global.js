jQuery(function( $ ){

	if( $( document ).scrollTop() > 134 ){
		$( '.entry-image' ).addClass( 'sticky' );
	}

	// Add invert class to entry image.
	$( document ).on('scroll', function(){

		if ( $( document ).scrollTop() > 134 ){
			$( '.entry-image' ).addClass( 'sticky' );

		} else {
			$( '.entry-image' ).removeClass( 'sticky' );
		}

	});

});