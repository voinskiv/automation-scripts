<?php
/**
 * Simplify Pro.
 *
 * This file adds functions to the Simplify Pro Theme.
 *
 * @package Simplify Pro
 * @author  Brian Gardner
 * @license GPL-2.0+
 * @link    https://briangardner.com/
 */

// Starts the engine.
require_once get_template_directory() . '/lib/init.php';

// Defines the child theme (do not remove).
define( 'CHILD_THEME_NAME', 'Simplify Pro' );
define( 'CHILD_THEME_URL', 'https://briangardner.com/themes/simplify/' );
define( 'CHILD_THEME_VERSION', '1.0.0' );

// Enqueues scripts and styles.
add_action( 'wp_enqueue_scripts', 'simplify_pro_enqueue_scripts_styles' );
function simplify_pro_enqueue_scripts_styles() {

	wp_enqueue_style(
		'simplify-pro-fonts',
		'//fonts.googleapis.com/css?family=Heboo:300,400|Lora:400,400i,700,700i',
		array(),
		CHILD_THEME_VERSION
	);

	wp_enqueue_style( 'dashicons' );

	$suffix = ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) ? '' : '.min';
	wp_enqueue_script(
		'simplify-pro-responsive-menu',
		get_stylesheet_directory_uri() . "/js/responsive-menus{$suffix}.js",
		array( 'jquery' ),
		CHILD_THEME_VERSION,
		true
	);

	wp_localize_script(
		'simplify-pro-responsive-menu',
		'genesis_responsive_menu',
		athk_responsive_menu_settings()
	);

	wp_enqueue_script(
		'simplify-pro',
		get_stylesheet_directory_uri() . '/js/simplify-pro.js',
		array( 'jquery', 'fitvids' ),
		CHILD_THEME_VERSION,
		true
	);

	if ( is_single() ) {

		wp_enqueue_script( 'simplify-pro-front-scripts', get_stylesheet_directory_uri() . '/js/global.js', array( 'jquery' ), '1.0.0' );

	}

}

// Defines responsive menu settings.
function athk_responsive_menu_settings() {

	$settings = array(
		'mainMenu'         => __( 'Menu', 'simplify-pro' ),
		'menuIconClass'    => 'dashicons-before dashicons-menu',
		'subMenu'          => __( 'Submenu', 'simplify-pro' ),
		'subMenuIconClass' => 'dashicons-before dashicons-arrow-down-alt2',
		'menuClasses'      => array(
			'combine' => array(
				'.nav-primary',
			),
			'others'  => array(),
		),
	);

	return $settings;

}

// Adds support for HTML5 markup structure.
add_theme_support(
	'html5',
	array(
		'caption',
		'comment-form',
		'comment-list',
		'gallery',
		'search-form',
	)
);

// Adds support for accessibility.
add_theme_support(
	'genesis-accessibility',
	array(
		'404-page',
		'drop-down-menu',
		'headings',
		'search-form',
		'skip-links',
	)
);

// Adds viewport meta tag for mobile browsers.
add_theme_support(
	'genesis-responsive-viewport'
);

// Registers primary navigation menus.
add_theme_support(
	'genesis-menus',
	array(
		'primary'   => __( 'Header Menu', 'simplify-pro' ),
	)
);

// Adds image sizes.
add_image_size( 'entry-image', 720, 720, true );

// Removes header right widget area.
unregister_sidebar( 'header-right' );

// Removes sidebars.
unregister_sidebar( 'sidebar' );
unregister_sidebar( 'sidebar-alt' );

// Removes site layouts.
genesis_unregister_layout( 'content-sidebar' );
genesis_unregister_layout( 'sidebar-content' );
genesis_unregister_layout( 'content-sidebar-sidebar' );
genesis_unregister_layout( 'sidebar-content-sidebar' );
genesis_unregister_layout( 'sidebar-sidebar-content' );

// Forces full-width-content layout setting.
add_filter( 'genesis_site_layout', '__genesis_return_full_width_content' );

// Removes output of primary navigation right extras.
remove_filter( 'genesis_nav_items', 'genesis_nav_right', 10, 2 );
remove_filter( 'wp_nav_menu_items', 'genesis_nav_right', 10, 2 );

// Removes output of unused admin settings metaboxes.
add_action( 'genesis_theme_settings_metaboxes', 'athk_remove_metaboxes' );
function athk_remove_metaboxes( $_genesis_admin_settings ) {

	remove_meta_box( 'genesis-theme-settings-header', $_genesis_admin_settings, 'main' );
	remove_meta_box( 'genesis-theme-settings-nav', $_genesis_admin_settings, 'main' );

}

// Removes output of header settings in Customizer.
add_filter( 'genesis_customizer_theme_settings_config', 'athk_remove_customizer_settings' );
function athk_remove_customizer_settings( $config ) {

	unset( $config['genesis']['sections']['genesis_header'] );
	return $config;

}

// Displays custom logo.
add_action( 'genesis_site_title', 'the_custom_logo', 0 );

// Repositions primary navigation menu.
remove_action( 'genesis_after_header', 'genesis_do_nav' );
add_action( 'genesis_header', 'genesis_do_nav', 12 );

// Adds entry image to entry.
add_action( 'genesis_entry_header', 'athk_entry_image', 4 );
function athk_entry_image() {

	if ( $image = genesis_get_image( array( 'format' => 'url', 'size' => 'entry-image' ) ) ) {
		printf( '<div class="entry-image"><div class="entry-sticky"><img src="%s" alt="%s" /></div></div>', $image, the_title_attribute( 'echo=0' ) );
	}

}

// Removes entry header.
remove_action( 'genesis_entry_header', 'genesis_entry_header_markup_open', 5 );
remove_action( 'genesis_entry_header', 'genesis_do_post_title' );
remove_action( 'genesis_entry_header', 'genesis_post_info', 12 );
remove_action( 'genesis_entry_header', 'genesis_entry_header_markup_close', 15 );

// Repositions entry header.
add_action( 'genesis_entry_content', 'genesis_entry_header_markup_open', 5 );
add_action( 'genesis_entry_content', 'genesis_post_info', 6 );
add_action( 'genesis_entry_content', 'genesis_do_post_title', 7 );
add_action( 'genesis_entry_content', 'genesis_entry_header_markup_close', 8 );

// Customizes entry meta in entry header.
add_filter( 'genesis_post_info', 'athk_entry_meta_header' );
function athk_entry_meta_header($post_info) {

	$post_info = '[post_date format="m.d.y"] [post_edit]';
	return $post_info;

}

// Adda dots after entry content on single posts.
add_action( 'genesis_entry_content', 'athk_entry_dots', 10 );
function athk_entry_dots() {

	if ( is_single() ) {

		echo '<p>. . .</p>';

	}

}

// Removes entry meta in entry footer.
remove_action( 'genesis_entry_footer', 'genesis_entry_footer_markup_open', 5 );
remove_action( 'genesis_entry_footer', 'genesis_post_meta' );
remove_action( 'genesis_entry_footer', 'genesis_entry_footer_markup_close', 15 );

// Modifies size of the Gravatar in author box.
add_filter( 'genesis_author_box_gravatar_size', 'athk_author_box_gravatar' );
function athk_author_box_gravatar( $size ) {

	return 90;

}

// Modifies size of the Gravatar in entry comments.
add_filter( 'genesis_comment_list_args', 'athk_comments_gravatar' );
function athk_comments_gravatar( $args ) {

	$args['avatar_size'] = 60;
	return $args;

}

// Repositions site footer.
remove_action( 'genesis_footer', 'genesis_footer_markup_open', 5 );
remove_action( 'genesis_footer', 'genesis_do_footer' );
remove_action( 'genesis_footer', 'genesis_footer_markup_close', 15 );
add_action( 'genesis_after', 'genesis_footer_markup_open', 5 );
add_action( 'genesis_after', 'genesis_do_footer' );
add_action( 'genesis_after', 'genesis_footer_markup_close', 15 );

// Remove favicon.
remove_action('wp_head', 'genesis_load_favicon');
