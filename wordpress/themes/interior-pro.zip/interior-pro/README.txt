INTERIOR PRO
http://my.studiopress.com/themes/interior/

INSTALL
1. Upload the Interior Pro theme folder via FTP to your wp-content/themes/ directory. (The Genesis parent theme needs to be in the wp-content/themes/ directory as well.)
2. Go to your WordPress dashboard and select Appearance.
3. Activate the Interior theme.
4. Inside your WordPress dashboard, go to Genesis > Theme Settings and configure them to your liking. To set up the theme like the demo, please visit http://my.studiopress.com/setup/interior-pro-theme/.

WIDGET AREAS
Primary Sidebar - This is the primary sidebar if you are using the Content/Sidebar or Sidebar/Conent Site Layout option.
Front Page 1 - This is the front page 1 widget area.
Front Page 2 - This is the front page 2 widget area.
Front Page 3 - This is the front page 3 widget area.
Before Footer - This is the before footer widget area.
Footer - This is the footer widget area.
After Entry - This is the after entry widget area.

ICON FONTS
The icons used in the Interior Pro theme are free of copyright and courtesy of http://ionicons.com/.

LOCALIZATION
The Interior Pro theme is translation ready.  More information about the translation process can be found here:http://codex.wordpress.org/Translating_WordPress/

SUPPORT
Please visit http://my.studiopress.com/help/ for theme support.

CHANGELOG

= 1.0 =
* Initial release