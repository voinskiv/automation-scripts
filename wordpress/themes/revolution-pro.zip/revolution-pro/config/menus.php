<?php
/**
 * Revolution Pro child theme.
 *
 * @author  StudioPress
 * @license GPL-2.0-or-later
 * @link    https://my.studiopress.com/themes/revolution-pro/
 * @package Revolution Pro
 */

/**
 * Supported Genesis navigation menus.
 */
return array(
	'primary'   => __( 'Left Menu', 'revolution-pro' ),
	'secondary' => __( 'Right Menu', 'revolution-pro' ),
);
