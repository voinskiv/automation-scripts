<?php
/**
 * Revolution Pro child theme.
 *
 * @author  StudioPress
 * @license GPL-2.0-or-later
 * @link    https://my.studiopress.com/themes/revolution-pro/
 * @package Revolution Pro
 */

/**
 * Custom Logo configuration.
 */
return array(
	'height'      => 100,
	'width'       => 488,
	'flex-height' => true,
	'flex-width'  => true,
);
