<?php
/**
 * Revolution Pro.
 *
 * This file adds the Blocks template to the Revolution Pro Theme.
 *
 * Template Name: Blocks
 *
 * @package Revolution Pro
 * @author  StudioPress
 * @license GPL-2.0-or-later
 * @link    https://my.studiopress.com/themes/revolution/
 */

add_filter( 'body_class', 'revolution_add_body_class' );
/**
 * Adds `custom-page` body class.
 *
 * @since 1.0.0
 *
 * @param array $classes Original body classes.
 * @return array Modified body classes.
 */
function revolution_add_body_class( $classes ) {

	$classes[] = 'custom-page';
	return $classes;

}

// Forces full width content layout.
add_filter( 'genesis_site_layout', '__genesis_return_full_width_content' );

// Removes entry header.
remove_action( 'genesis_entry_header', 'genesis_entry_header_markup_open', 5 );
remove_action( 'genesis_entry_header', 'genesis_do_post_title' );
remove_action( 'genesis_entry_header', 'genesis_entry_header_markup_close', 15 );

// Removes entry edit link.
add_filter( 'genesis_edit_post_link', '__return_false' );

// Runs the Genesis loop.
genesis();
