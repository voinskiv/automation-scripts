NO SIDEBAR PRO
http://my.studiopress.com/themes/no-sidebar/

INSTALL
1. Upload the No Sidebar theme folder via FTP to your wp-content/themes/ directory. (The Genesis parent theme needs to be in the wp-content/themes/ directory as well.)
2. Go to your WordPress dashboard and select Appearance.
3. Activate the No Sidebar theme.
4. Inside your WordPress dashboard, go to Genesis > Theme Settings and configure them to your liking.

WIDGET AREAS
Welcome Message - This is the welcome message widget area and will display above posts on the front page.
After Entry - This is the widget area and will display after single entries.
Newsletter Signup - This is the newsletter signup widget area and will display on the newsletter page template.

CUSTOM BACKGROUND
This theme supports custom background, which is a native WordPress function.

ICON FONTS
The icons used in the Atmosphere Pro theme are free of copyright and courtesy of http://ionicons.com/.

LOCALIZATION
The No Sidebar Pro theme is translation ready.  More information about the translation process can be found here:http://codex.wordpress.org/Translating_WordPress/

SUPPORT
Please visit http://my.studiopress.com/help/ for theme support.

CHANGELOG

= 1.0 =
* Initial release

= 1.0.1 =
* Update blog page template
* Remove IE8 CSS fix for images

= 1.0.2 =
* Adjust mobile menu button ID
* Improve skip links

= 1.0.3 =
* Add rems to genesis-accessibility
* Adjust paginated mobile layout
* Update After Entry fadein

= 1.0.4 =
* Update color customizer text