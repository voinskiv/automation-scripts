jQuery(document).ready(function($) {

	$(".entry-background").backstretch([BackStretchImg.src],{duration:3000,fade:750});

});