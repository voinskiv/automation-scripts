jQuery( function ( $ ) {

	// FitVids
	$('.site-inner').fitVids();

});
