# boss-pro
Repository for the Boss Pro theme by Design by Bloom.

=1.0.1=
* Added the ability to upload the front page logo image from the customizer.
* Fixed a localization error.
* Fixed a bug that prevented the uploaded header to work with a page header.
* Fixed a bug with the WooCommerce notice URL.
* Fixed a bug with the Front Page 4 image not updating.
* Fixed featured post bug in footer.

=1.0.0=
* Initial release.